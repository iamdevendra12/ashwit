var express=require("express");
var router=express();
var db=require("../db");
router.get('/',(request,response)=>{
    var connection=db.connect()
    var mysql=`select id,title,description,price from product`
    connection.query(mysql,(error,result)=>{
        connection.end()
        if(error==null)
        {
            response.send(JSON.stringify(result))
        }else
        {
            response.send(JSON.stringify(error))
        }
    })
})
router.post('/',(request,response)=>{
    const{title,description,price}=request.body
    var connection=db.connect()
    var mysql=`insert into product (title,description,price)values('${title}','${description}',${price})`
    connection.query(mysql,(error,result)=>{
        connection.end()
        if(error==null)
        {
            response.send(JSON.stringify(result))
        }else
        {
            response.send(JSON.stringify(error))
        }
    })
})
module.exports=router