create table product(id integer primary key auto_increment,title varchar(50),description varchar(100),price float);
create table category(id integer primary key auto_increment,title varchar(50),description varchar(100));
create table user(id integer primary key auto_increment,name varchar(50),email varchar(100),phone varchar(15));
insert into category(title,description) values('home','home appliances');
insert into category(title,description) values('electronic','electronic appliances');

